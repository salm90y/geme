package com.example.combat3multiplayer

class EmulationLoop(
    private val session:GameSession,
    private val clock:FrameClock=FrameClock()
) {
    @Volatile var running=false
        private set
    private var thread:Thread?=null

    fun start(input:()->InputFrame){
        if(running)return
        running=true
        clock.reset()
        thread=Thread {
            while(running){
                session.submit(input())
                clock.waitForNextFrame()
            }
        }.apply { name="Combat3-Emulation"; start() }
    }

    fun stop(){
        running=false
        thread?.interrupt()
        thread=null
    }
}
