package com.example.combat3multiplayer

import java.util.TreeMap

class InputSynchronizer {
    private val remote=TreeMap<Long,InputFrame>()
    private var lastRemote=InputFrame(0,2,0)

    fun pushRemote(input:InputFrame){ remote[input.frame]=input }
    fun inputFor(frame:Long):InputFrame {
        val exact=remote.remove(frame)
        if(exact!=null){lastRemote=exact;return exact}
        // Hold the most recent remote input to keep the emulation clock moving.
        return lastRemote.copy(frame=frame)
    }
}
