package com.example.combat3multiplayer

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns

data class GameFile(val uri: Uri, val name: String, val size: Long)

class GameFileImporter(private val context: Context) {
    fun inspect(uri: Uri): GameFile? {
        val cr=context.contentResolver
        var name="game"
        var size=-1L
        cr.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE),null,null,null)?.use { c ->
            if(c.moveToFirst()){
                val ni=c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si=c.getColumnIndex(OpenableColumns.SIZE)
                if(ni>=0) name=c.getString(ni) ?: name
                if(si>=0 && !c.isNull(si)) size=c.getLong(si)
            }
        }
        val lower=name.lowercase()
        if(!(lower.endsWith(".cue") || lower.endsWith(".bin") || lower.endsWith(".chd") ||
             lower.endsWith(".img") || lower.endsWith(".pbp") || lower.endsWith(".iso"))) return null
        return GameFile(uri,name,size)
    }
}
