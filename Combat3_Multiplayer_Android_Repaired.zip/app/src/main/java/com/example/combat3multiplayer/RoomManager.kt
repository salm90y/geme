package com.example.combat3multiplayer

import kotlin.random.Random

data class Room(val code:String, val host:Boolean, val status:String="WAITING", val players:Int=1)

class RoomManager {
    var room: Room? = null
        private set

    fun create(): Room {
        val code=(1..6).map{('A'.code+Random.nextInt(26)).toChar()}.joinToString("")
        return Room(code,true).also{room=it}
    }

    fun join(code:String): Room {
        require(code.length==6) {"Room code must be 6 characters"}
        return Room(code.uppercase(),false,"CONNECTED",2).also{room=it}
    }

    fun leave(){ room=null }
}
