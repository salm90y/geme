package com.example.combat3multiplayer

import android.app.Activity
import android.os.Bundle
import android.view.*
import android.widget.*

class MainActivity : Activity() {
    private val rooms=RoomManager()

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        val root=FrameLayout(this)
        root.setBackgroundColor(android.graphics.Color.BLACK)
        val gameSurface = GameSurface(this)
        root.addView(gameSurface)
        val gear=TextView(this).apply{text="⚙";textSize=22f;alpha=.7f;setTextColor(android.graphics.Color.WHITE);setPadding(20,10,20,10)}
        root.addView(gear,FrameLayout.LayoutParams(-2,-2))
        gear.setOnClickListener{showMenu()}
        setContentView(root)
    }

    private fun showMenu() {
        val options=arrayOf("Create room","Join room","Gamepad","Network status","Select user-owned ISO","Close")
        AlertDialog.Builder(this).setTitle("Combat 3 Multiplayer").setItems(options){d,w->
            when(w) {
                0 -> { val r=rooms.create(); Toast.makeText(this,"Room: ${r.code}",Toast.LENGTH_LONG).show() }
                1 -> joinDialog()
                2 -> Toast.makeText(this,"Gamepad auto-detection enabled",Toast.LENGTH_SHORT).show()
                3 -> Toast.makeText(this,"Netplay transport ready for production backend",Toast.LENGTH_SHORT).show()
                4 -> Toast.makeText(this,"Choose a game file you own",Toast.LENGTH_SHORT).show()
            }
        }.show()
    }

    private fun joinDialog() {
        val input=EditText(this).apply{hint="6-character room code";isSingleLine=true}
        AlertDialog.Builder(this).setTitle("Join room").setView(input)
            .setPositiveButton("Join"){_,_->try{
                val r=rooms.join(input.text.toString().trim())
                Toast.makeText(this,"Connected to ${r.code}",Toast.LENGTH_SHORT).show()
            }catch(e:Exception){Toast.makeText(this,e.message,Toast.LENGTH_SHORT).show()}}
            .setNegativeButton("Cancel",null).show()
    }

    override fun dispatchKeyEvent(e:KeyEvent):Boolean {
        findGame(window.decorView as ViewGroup)?.onGamepadKey(e)
        return super.dispatchKeyEvent(e)
    }
    override fun dispatchGenericMotionEvent(e:MotionEvent):Boolean {
        if(e.source and InputDevice.SOURCE_JOYSTICK==InputDevice.SOURCE_JOYSTICK){
            findGame(window.decorView as ViewGroup)?.onGamepadMotion(e);return true
        }
        return super.dispatchGenericMotionEvent(e)
    }
    private fun findGame(v:ViewGroup):GameSurface? {
        for(i in 0 until v.childCount){val c=v.getChildAt(i);if(c is GameSurface)return c;if(c is ViewGroup)findGame(c)?.let{return it}}
        return null
    }
}
