package com.example.combat3multiplayer

class FrameClock(private val fps:Double=60.0) {
    private val step=(1_000_000_000.0/fps).toLong()
    private var next=System.nanoTime()
    fun reset(){next=System.nanoTime()}
    fun waitForNextFrame(){
        next+=step
        val sleep=next-System.nanoTime()
        if(sleep>0){
            try{Thread.sleep(sleep/1_000_000,(sleep%1_000_000).toInt())}catch(_:InterruptedException){}
        } else if(sleep < -step*4) next=System.nanoTime()
    }
}
