package com.example.combat3multiplayer

import android.view.KeyEvent
import android.view.MotionEvent
import kotlin.math.abs

class ControllerMapper {
    var state=ControllerState()
        private set

    fun key(keyCode:Int, down:Boolean) {
        val bit=when(keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> RetroPad.UP
            KeyEvent.KEYCODE_DPAD_DOWN -> RetroPad.DOWN
            KeyEvent.KEYCODE_DPAD_LEFT -> RetroPad.LEFT
            KeyEvent.KEYCODE_DPAD_RIGHT -> RetroPad.RIGHT
            KeyEvent.KEYCODE_BUTTON_A -> RetroPad.A
            KeyEvent.KEYCODE_BUTTON_B -> RetroPad.B
            KeyEvent.KEYCODE_BUTTON_X -> RetroPad.X
            KeyEvent.KEYCODE_BUTTON_Y -> RetroPad.Y
            KeyEvent.KEYCODE_BUTTON_L1 -> RetroPad.L
            KeyEvent.KEYCODE_BUTTON_R1 -> RetroPad.R
            KeyEvent.KEYCODE_BUTTON_START -> RetroPad.START
            KeyEvent.KEYCODE_BUTTON_SELECT -> RetroPad.SELECT
            else -> -1
        }
        if(bit>=0) {
            val mask=1 shl bit
            state=state.copy(buttons=if(down) state.buttons or mask else state.buttons and mask.inv())
        }
    }

    fun motion(event:MotionEvent) {
        val x=event.getAxisValue(MotionEvent.AXIS_X)
        val y=event.getAxisValue(MotionEvent.AXIS_Y)
        state=state.copy(axisX=if(abs(x)<.15f) 0f else x, axisY=if(abs(y)<.15f) 0f else y)
    }
}
