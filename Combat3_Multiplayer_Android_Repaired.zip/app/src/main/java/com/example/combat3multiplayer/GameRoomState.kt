package com.example.combat3multiplayer

data class GameRoomState(
    val roomCode:String,
    val gameFingerprint:String,
    val frame:Long,
    val player1Connected:Boolean,
    val player2Connected:Boolean,
    val latencyMs:Int
)
