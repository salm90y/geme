package com.example.combat3multiplayer

class MatchCoordinator(
    private val core:NativeCoreBridge,
    private val sync:InputSynchronizer
) {
    fun runFrame(local:InputFrame) {
        val remote=sync.inputFor(local.frame)
        core.nativeRunFrame(local.frame,local.buttons,remote.buttons)
    }
}
