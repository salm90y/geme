package com.example.combat3multiplayer

/**
 * Stage 3 synchronization skeleton.
 *
 * Production implementation must connect this interface to a real low-latency
 * peer/relay transport and the selected emulator/core's frame execution API.
 */
class NetplaySession(private val transport: NetplayTransport) {
    private var running=false
    private var localFrame=0L

    fun start(roomCode:String, onStatus:(String)->Unit) {
        running=true
        transport.connect(roomCode) { msg -> onStatus(msg) }
    }

    fun submitLocalInput(buttons:Int, x:Float, y:Float) {
        if(!running) return
        localFrame++
        transport.send(InputFrame(localFrame,1,buttons,x,y))
    }

    fun stop() {
        running=false
        transport.disconnect()
    }
}
