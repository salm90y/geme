package com.example.combat3multiplayer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.view.SurfaceHolder

class EmulatorRenderer(private val holder: SurfaceHolder) {
    @Volatile private var frame: VideoFrame? = null

    fun submit(video: VideoFrame) { frame = video }

    fun draw() {
        val f = frame ?: return
        if (f.width <= 0 || f.height <= 0) return
        val bitmap = Bitmap.createBitmap(f.width, f.height, Bitmap.Config.ARGB_8888)
        try {
            bitmap.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(f.pixels))
            val canvas: Canvas = holder.lockCanvas() ?: return
            try {
                canvas.drawColor(android.graphics.Color.BLACK)
                canvas.drawBitmap(bitmap, null,
                    Rect(0, 0, canvas.width, canvas.height), null)
            } finally {
                holder.unlockCanvasAndPost(canvas)
            }
        } finally {
            bitmap.recycle()
        }
    }
}
