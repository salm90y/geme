package com.example.combat3multiplayer

data class MatchValidation(val ok:Boolean,val reason:String="")
object MatchValidator {
    fun validate(localRoom:String, localHash:String, remote:HelloPacket):MatchValidation {
        if(localRoom!=remote.room) return MatchValidation(false,"ROOM_MISMATCH")
        if(localHash!=remote.gameHash) return MatchValidation(false,"GAME_MISMATCH")
        if(remote.protocol!=1) return MatchValidation(false,"PROTOCOL_MISMATCH")
        return MatchValidation(true)
    }
}
