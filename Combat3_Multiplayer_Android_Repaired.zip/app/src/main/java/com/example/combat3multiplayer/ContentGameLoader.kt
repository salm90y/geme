package com.example.combat3multiplayer

import android.content.Context
import android.net.Uri
import java.io.File

class ContentGameLoader(private val context: Context) {
    fun copyToPrivateFile(uri: Uri): File {
        val name = "game_content.bin"
        val out = File(context.cacheDir, name)
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Unable to open game file" }
            out.outputStream().use { output -> input.copyTo(output) }
        }
        return out
    }
}
