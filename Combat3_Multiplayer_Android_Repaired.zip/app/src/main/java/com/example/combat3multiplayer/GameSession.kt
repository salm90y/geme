package com.example.combat3multiplayer

import android.content.Context
import android.net.Uri

class GameSession(private val context: Context) {
    val frontend = LibretroFrontend()
    private val core = NativeCoreBridge()
    private val sync = InputSynchronizer()
    private val files = ContentGameLoader(context)

    var loaded = false
        private set

    fun loadCore(path: String): Boolean {
        core.nativeConfigureFrontend(frontend)
        return core.nativeLoadCore(path)
    }

    fun loadGame(uri: Uri): Boolean {
        val file = files.copyToPrivateFile(uri)
        loaded = core.nativeLoadContent(file.absolutePath)
        return loaded
    }

    fun submit(local: InputFrame) {
        if (!loaded) return
        val remote = sync.inputFor(local.frame)
        core.nativeRunFrame(local.frame, local.buttons, remote.buttons)
    }

    fun pushRemote(input: InputFrame) { sync.pushRemote(input) }

    fun close() {
        if (loaded) core.nativeUnloadContent()
        core.nativeUnloadCore()
        loaded = false
    }
}
