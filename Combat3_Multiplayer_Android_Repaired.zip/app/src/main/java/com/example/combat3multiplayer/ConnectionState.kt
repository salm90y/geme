package com.example.combat3multiplayer

enum class ConnectionState { IDLE, CONNECTING, CONNECTED, MATCHING, PLAYING, DISCONNECTED, ERROR }
