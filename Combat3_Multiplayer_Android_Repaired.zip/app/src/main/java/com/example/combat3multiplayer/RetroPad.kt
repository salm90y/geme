package com.example.combat3multiplayer

object RetroPad {
    const val B=0; const val Y=1; const val SELECT=2; const val START=3
    const val UP=4; const val DOWN=5; const val LEFT=6; const val RIGHT=7
    const val A=8; const val X=9; const val L=10; const val R=11
}
