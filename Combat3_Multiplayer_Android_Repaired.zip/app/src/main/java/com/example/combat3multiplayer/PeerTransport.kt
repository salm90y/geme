package com.example.combat3multiplayer

/**
 * Production transport contract. Implement with WebRTC DataChannel or a
 * low-latency relay; the UI and emulator code do not depend on the transport.
 */
interface PeerTransport : NetplayTransport {
    fun ping():Int
    fun isConnected():Boolean
}
