package com.example.combat3multiplayer
data class VideoFrame(val pixels:ByteArray,val width:Int,val height:Int,val pitch:Int)
data class AudioBlock(val samples:ShortArray,val frames:Int,val sampleRate:Int)
class LibretroFrontend {
 @Volatile var lastVideo:VideoFrame?=null
 @Volatile var lastAudio:AudioBlock?=null
 fun onVideo(p:ByteArray,w:Int,h:Int,pitch:Int){lastVideo=VideoFrame(p,w,h,pitch)}
 fun onAudio(s:ShortArray,frames:Int,rate:Int){lastAudio=AudioBlock(s,frames,rate)}
}
