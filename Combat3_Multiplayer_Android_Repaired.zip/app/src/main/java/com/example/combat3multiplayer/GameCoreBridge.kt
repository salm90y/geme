package com.example.combat3multiplayer

/**
 * Emulator abstraction. The app intentionally does not ship copyrighted ROMs.
 * A real PS1 core/emulator integration is plugged in here in the next build.
 */
interface GameCoreBridge {
    fun loadUserOwnedGame(uri:String): Boolean
    fun reset()
    fun step(frame:Long, player1:InputFrame, player2:InputFrame)
    fun renderTarget(): Any?
}

class PlaceholderGameCore : GameCoreBridge {
    override fun loadUserOwnedGame(uri:String)=true
    override fun reset(){}
    override fun step(frame:Long, player1:InputFrame, player2:InputFrame){}
    override fun renderTarget():Any?=null
}
