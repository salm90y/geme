package com.example.combat3multiplayer

/** JNI bridge. The native library is loaded only when a core session is actually used. */
class NativeCoreBridge {
    private object NativeLoader {
        @Volatile var loaded = false
        fun ensureLoaded(): Boolean {
            if (loaded) return true
            return try {
                System.loadLibrary("combat3bridge")
                loaded = true
                true
            } catch (_: UnsatisfiedLinkError) {
                false
            }
        }
    }

    fun nativeConfigureFrontend(frontend: LibretroFrontend) {
        check(NativeLoader.ensureLoaded()) { "Native Combat 3 bridge is unavailable on this device" }
        nativeConfigureFrontend0(frontend)
    }

    fun nativeLoadCore(path: String): Boolean {
        check(NativeLoader.ensureLoaded()) { "Native Combat 3 bridge is unavailable on this device" }
        return nativeLoadCore0(path)
    }

    fun nativeLoadContent(path: String): Boolean {
        check(NativeLoader.ensureLoaded()) { "Native Combat 3 bridge is unavailable on this device" }
        return nativeLoadContent0(path)
    }

    fun nativeSetPads(p1: Int, p2: Int) {
        check(NativeLoader.ensureLoaded())
        nativeSetPads0(p1, p2)
    }

    fun nativeRunFrame(frame: Long, p1Buttons: Int, p2Buttons: Int) {
        check(NativeLoader.ensureLoaded())
        nativeRunFrame0(frame, p1Buttons, p2Buttons)
    }

    fun nativeUnloadContent() {
        if (NativeLoader.loaded) nativeUnloadContent0()
    }

    fun nativeUnloadCore() {
        if (NativeLoader.loaded) nativeUnloadCore0()
    }

    private external fun nativeConfigureFrontend0(frontend: LibretroFrontend)
    private external fun nativeLoadCore0(path: String): Boolean
    private external fun nativeLoadContent0(path: String): Boolean
    private external fun nativeSetPads0(p1: Int, p2: Int)
    private external fun nativeRunFrame0(frame: Long, p1Buttons: Int, p2Buttons: Int)
    private external fun nativeUnloadContent0()
    private external fun nativeUnloadCore0()
}
