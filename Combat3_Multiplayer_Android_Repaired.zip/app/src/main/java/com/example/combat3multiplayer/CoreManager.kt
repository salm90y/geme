package com.example.combat3multiplayer

import android.content.Context
import java.io.File

class CoreManager(private val context:Context) {
    private val dir=File(context.filesDir,"cores").apply{mkdirs()}
    fun coreDirectory():File=dir
    fun findPs1Core():File? = dir.listFiles()?.firstOrNull {
        it.name.contains("duckstation",true) && it.extension=="so"
    }
}
