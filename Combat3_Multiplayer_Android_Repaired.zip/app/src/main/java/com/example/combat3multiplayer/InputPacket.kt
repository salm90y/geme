package com.example.combat3multiplayer

data class InputPacket(
    val roomCode:String,
    val frame:Long,
    val player:Int,
    val buttons:Int,
    val axisX:Float=0f,
    val axisY:Float=0f
) {
    fun encode():String =
        listOf(roomCode,frame,player,buttons,axisX,axisY).joinToString("|")

    companion object {
        fun decode(value:String):InputPacket {
            val p=value.split("|")
            require(p.size==6)
            return InputPacket(p[0],p[1].toLong(),p[2].toInt(),p[3].toInt(),
                p[4].toFloat(),p[5].toFloat())
        }
    }
}
