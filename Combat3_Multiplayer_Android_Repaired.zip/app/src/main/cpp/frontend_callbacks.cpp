#include <jni.h>
#include <android/log.h>
#include <cstdint>
#include <cstdlib>
#include <cstring>

#define TAG "Combat3Frontend"

static JavaVM* g_vm = nullptr;
static jobject g_frontend = nullptr;
static jmethodID g_video = nullptr;
static jmethodID g_audio = nullptr;

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_combat3multiplayer_NativeCoreBridge_nativeConfigureFrontend(
    JNIEnv* env, jobject, jobject frontend) {
    if (g_frontend) env->DeleteGlobalRef(g_frontend);
    g_frontend = frontend ? env->NewGlobalRef(frontend) : nullptr;
    if (g_frontend) {
        jclass cls = env->GetObjectClass(frontend);
        g_video = env->GetMethodID(cls, "onVideo", "([BIII)V");
        g_audio = env->GetMethodID(cls, "onAudio", "([SII)V");
    }
    __android_log_print(ANDROID_LOG_INFO, TAG, "Frontend configured");
}

/* Called by the Libretro loader in the next binding layer. */
void combat3_emit_video(const void* data, unsigned w, unsigned h, size_t pitch) {
    if (!g_vm || !g_frontend || !data || !w || !h) return;
    JNIEnv* env=nullptr;
    bool attached=false;
    if (g_vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (g_vm->AttachCurrentThread(&env,nullptr) != JNI_OK) return;
        attached=true;
    }
    const size_t bytes=pitch*h;
    jbyteArray arr=env->NewByteArray((jsize)bytes);
    if (arr) {
        env->SetByteArrayRegion(arr,0,(jsize)bytes,(const jbyte*)data);
        env->CallVoidMethod(g_frontend,g_video,arr,(jint)w,(jint)h,(jint)pitch);
        env->DeleteLocalRef(arr);
    }
    if (attached) g_vm->DetachCurrentThread();
}

void combat3_emit_audio(const int16_t* data, size_t frames, unsigned rate) {
    if (!g_vm || !g_frontend || !data || !frames) return;
    JNIEnv* env=nullptr;
    bool attached=false;
    if (g_vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (g_vm->AttachCurrentThread(&env,nullptr) != JNI_OK) return;
        attached=true;
    }
    jsize n=(jsize)(frames*2);
    jshortArray arr=env->NewShortArray(n);
    if (arr) {
        env->SetShortArrayRegion(arr,0,n,(const jshort*)data);
        env->CallVoidMethod(g_frontend,g_audio,arr,(jint)frames,(jint)rate);
        env->DeleteLocalRef(arr);
    }
    if (attached) g_vm->DetachCurrentThread();
}
