#include <android/log.h>
#include <cstdint>
#include <cstddef>
#include "libretro_min.h"

extern void combat3_emit_video(const void*, unsigned, unsigned, size_t);
extern void combat3_emit_audio(const int16_t*, size_t, unsigned);

static uint16_t g_pad[2] = {0,0};
static unsigned g_width = 0, g_height = 0;
static double g_fps = 60.0, g_sample_rate = 44100.0;

static bool environment(unsigned cmd, void* data) {
    // Common frontend queries. Unknown commands are rejected safely.
    switch (cmd) {
        case 9: // RETRO_ENVIRONMENT_SET_PIXEL_FORMAT
            return true;
        case 10: // SET_INPUT_DESCRIPTORS
            return true;
        case 16: // SET_SYSTEM_AV_INFO
            return true;
        case 27: // GET_LOG_INTERFACE
            return false;
        default:
            (void)data;
            return false;
    }
}

static void video_refresh(const void* data, unsigned w, unsigned h, size_t pitch) {
    g_width=w; g_height=h;
    if (data) combat3_emit_video(data,w,h,pitch);
}

static void audio_sample(int16_t l, int16_t r) {
    int16_t s[2]={l,r};
    combat3_emit_audio(s,1,(unsigned)g_sample_rate);
}

static size_t audio_batch(const int16_t* data, size_t frames) {
    if (data && frames) combat3_emit_audio(data,frames,(unsigned)g_sample_rate);
    return frames;
}

static void input_poll() {}

static int16_t input_state(unsigned port, unsigned device, unsigned index, unsigned id) {
    if (device != 1 || index != 0 || port > 1 || id > 15) return 0;
    return (g_pad[port] & (uint16_t)(1u << id)) ? 1 : 0;
}

extern "C" void combat3_set_pad(unsigned port, uint16_t bits) {
    if (port < 2) g_pad[port]=bits;
}

extern "C" void combat3_configure_callbacks() {
    // Function pointers are installed by the loader after resolving the core ABI.
}
extern "C" retro_environment_t combat3_env(){return environment;}
extern "C" retro_video_refresh_t combat3_video(){return video_refresh;}
extern "C" retro_audio_sample_t combat3_audio(){return audio_sample;}
extern "C" retro_audio_sample_batch_t combat3_audio_batch(){return audio_batch;}
extern "C" retro_input_poll_t combat3_poll(){return input_poll;}
extern "C" retro_input_state_t combat3_state(){return input_state;}
