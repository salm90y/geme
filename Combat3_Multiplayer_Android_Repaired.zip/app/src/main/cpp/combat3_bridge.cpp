#include <jni.h>
#include "libretro_min.h"

extern "C" bool combat3_load_core(const char*);
extern "C" void combat3_unload_core();
extern "C" void combat3_run();
extern "C" bool combat3_load_content(const char*);
extern "C" void combat3_unload_content();
extern "C" void combat3_set_pad(unsigned, uint16_t);

extern "C" JNIEXPORT void JNICALL
Java_com_example_combat3multiplayer_NativeCoreBridge_nativeConfigureFrontend0(JNIEnv* e,jobject,jobject frontend){
    (void)e; (void)frontend;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_combat3multiplayer_NativeCoreBridge_nativeLoadCore0(JNIEnv* e,jobject,jstring path){
 const char* p=e->GetStringUTFChars(path,nullptr);
 bool ok=combat3_load_core(p);
 e->ReleaseStringUTFChars(path,p);
 return ok?JNI_TRUE:JNI_FALSE;
}
extern "C" JNIEXPORT void JNICALL
Java_com_example_combat3multiplayer_NativeCoreBridge_nativeRunFrame0(JNIEnv*,jobject,jlong,jint,jint){
 combat3_run();
}
extern "C" JNIEXPORT void JNICALL
Java_com_example_combat3multiplayer_NativeCoreBridge_nativeUnloadCore0(JNIEnv*,jobject){
 combat3_unload_core();
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_combat3multiplayer_NativeCoreBridge_nativeLoadContent0(JNIEnv* e,jobject,jstring path){
 const char* p=e->GetStringUTFChars(path,nullptr);
 bool ok=combat3_load_content(p);
 e->ReleaseStringUTFChars(path,p);
 return ok?JNI_TRUE:JNI_FALSE;
}
extern "C" JNIEXPORT void JNICALL
Java_com_example_combat3multiplayer_NativeCoreBridge_nativeUnloadContent0(JNIEnv*,jobject){
 combat3_unload_content();
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_combat3multiplayer_NativeCoreBridge_nativeSetPads0(JNIEnv*,jobject,jint p1,jint p2){
    combat3_set_pad(0,(uint16_t)p1);
    combat3_set_pad(1,(uint16_t)p2);
}
