plugins {
 id("com.android.application")
 id("org.jetbrains.kotlin.android")
}
android {
    ndkVersion = "27.0.12077973"
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
        }
    }
 namespace="com.example.combat3multiplayer"
 compileSdk=35
 defaultConfig {
  applicationId="com.example.combat3multiplayer"
  minSdk=26
  targetSdk=35
  versionCode=2
  versionName="0.2.0"
 }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.appcompat:appcompat:1.7.0")
 implementation("androidx.activity:activity-ktx:1.10.0")
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
